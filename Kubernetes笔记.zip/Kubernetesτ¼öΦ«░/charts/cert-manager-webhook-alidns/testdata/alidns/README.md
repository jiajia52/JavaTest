# Solver testdata directory

```json
{
  "accessKeyId": "your aliyun accessKeyId",
  "accessKeySecret": "your aliyun accessKeySecret",
  "regionId": "your region id",
  "ttl": 600
}
```
